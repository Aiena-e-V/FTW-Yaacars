Find documentation about installation here!

http://openair-alliance.eu/yaacars/doc/doku.php?id=yaacars-interface

Please read!
