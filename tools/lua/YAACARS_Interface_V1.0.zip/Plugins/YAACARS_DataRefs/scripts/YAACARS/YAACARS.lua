
function write_callback() end

yc1 = create_dataref("yaacars/connected", "number", write_callback)
yc2 = create_dataref("yaacars/tracking", "number", write_callback)
yc3 = create_dataref("yaacars/alive", "number", write_callback)

yc4 = create_dataref("yaacars/fuel_kg", "number", write_callback)
yc5 = create_dataref("yaacars/payload_kg", "number", write_callback)
